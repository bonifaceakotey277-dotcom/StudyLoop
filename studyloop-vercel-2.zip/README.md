# StudyLoop on Vercel

## What's here
- `index.html` – the StudyLoop app (works standalone; saves progress in the browser)
- `config.js` – your public Supabase settings (sign-in)
- `api/ai.js` – serverless function that checks the sign-in and calls the Anthropic API with your key
- `vercel.json` – allows the function to run up to 60 seconds

## 1. Set up sign-in (Supabase, free tier is fine)
1. Create a project at supabase.com.
2. Authentication -> Providers: make sure **Email** is enabled. Decide whether to require email confirmation
   (Authentication -> Sign In / Providers -> Email -> "Confirm email").
3. Authentication -> URL Configuration: set **Site URL** to your Vercel address (e.g. `https://studyloop.vercel.app`)
   so confirmation and password-reset links come back to your site.
4. Project Settings -> API: copy the **Project URL** and the **anon public** key.
5. Paste them into `config.js` (these two values are public and safe to commit).

## 2. Deploy
1. Get an API key from the Anthropic Console and set a spending limit.
2. Put this folder in a GitHub repo, then in Vercel choose **Add New -> Project** and import it
   (or run `npx vercel` inside this folder).
3. In **Project Settings -> Environment Variables** add:
   - `ANTHROPIC_API_KEY` (required)
   - `SUPABASE_URL` (required for sign-in) – same Project URL as in config.js
   - `SUPABASE_ANON_KEY` (required for sign-in) – same anon key as in config.js
   - `ALLOWED_ORIGIN` (optional) – your site URL
   - `RATE_LIMIT_PER_MIN` (optional) – requests per user per minute, default 20
   - `CLAUDE_MODEL` (optional) – default `claude-sonnet-5-5`
   - `ACCESS_CODE` (only if you skip sign-in) – shared password
4. Redeploy so the variables take effect.

## How sign-in behaves
- Visitors see a sign-in / create-account screen before the app. "Forgot password?" sends a reset email.
- The AI only answers requests that carry a valid sign-in; the server checks the token with Supabase.
- Each person's study data is kept separately in the browser, so two people sharing one device don't see each other's courses.
- **Sign out** (top-right) saves that person's data on the device and clears the screen.
- Leave `config.js` empty to run without sign-in (then use `ACCESS_CODE`).

## What works outside claude.ai
Works: notes, flashcards, quizzes, mock exams, written marking, question papers, AI tutor, focus timer, planner, downloads.
Not yet available: cloud sync across devices, study groups, leaderboard, live sessions (these need database tables, which is the next step).
Study data lives in the browser, so clearing browser data erases it until cloud sync is added.
