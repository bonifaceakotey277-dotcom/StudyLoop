// Public settings (safe to publish). Fill these in from your Supabase project:
// Project Settings -> API -> Project URL and the "anon public" key.
// Leave both empty to run without sign-in (uses ACCESS_CODE instead).
window.SL_CONFIG = {
  supabaseUrl: "",
  supabaseAnonKey: ""
};
